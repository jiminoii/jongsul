from django.apps import AppConfig


class StayConfig(AppConfig):
    name = 'stay'
