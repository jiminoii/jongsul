from django.apps import AppConfig


class FasConfig(AppConfig):
    name = 'fas'
